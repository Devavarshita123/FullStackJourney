function calculateGrade(){
    const name=document.getElementById("name").value.trim();
    const sub1=Number(document.getElementById("sub1").value);
    const sub2=Number(document.getElementById("sub2").value);
    const sub3=Number(document.getElementById("sub3").value);
    const sub4=Number(document.getElementById("sub4").value);
    const sub5=Number(document.getElementById("sub5").value);
    const output=document.getElementById("output");

    if(!name || isNaN(sub1) || isNaN(sub2) || isNaN(sub3) || isNaN(sub4) || isNaN(sub5)){
        output.innerHTML="! Please fill in for all fields correctly.";
        return;
    }

    let marks=[sub1,sub2,sub3,sub4,sub5];
    for (let mark of marks) {
        if(mark <0 || marks>100){
            output.innerHTML="! Please enter marks between 0 and 100.";
            return;
        }
    }
    const total=sub1+sub2+sub3+sub4+sub5;
    const average=total/5;
    let grade;
    if(average>=90){
        grade="A+";
    }
    else if(average>=80){
        grade="A";
    }
    else if(average>=70){
        grade="B";
    }
    else if(average>=60){
        grade="C";
    }
    else{
        grade="D";
    }
    output.innerHTML=`
    🎓student name: <strong>${name}</strong><br>
    📊Total Marks: <strong>${total}/500</strong><br>
    📈Average: <strong>${average.toFixed(2)}</strong><br>
    🏆Grade: <strong>${grade}</strong><br>`;

}

function resetForm()
{
    document.getElementById("name").value='';
    document.getElementById("sub1").value='';
    document.getElementById("sub2").value='';
    document.getElementById("sub3").value='';
    document.getElementById("sub4").value='';
    document.getElementById("sub5").value='';
    document.getElementById("output").innerHTML='';
}
